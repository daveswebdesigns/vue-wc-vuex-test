<template>
  <div class="home">
    <h1>This is the home view</h1>
  </div>
</template>

<script>


export default {
  name: 'Home',
}
</script>
