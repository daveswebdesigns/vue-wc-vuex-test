<template>
  <div id="app-wc">
    <router-view />
  </div>
</template>

<script>
import router from './router'
export default {
	router
}
</script>