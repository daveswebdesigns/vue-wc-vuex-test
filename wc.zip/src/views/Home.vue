<template>
  <div class="home">
    <h1>This is the home view</h1>
    <img alt="Vue logo" src="../assets/logo.png">
  </div>
</template>

<script>


export default {
  name: 'Home',
}
</script>
